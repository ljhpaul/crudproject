package com.shinhan.common;

public interface CommonControllerInterface {
	
	public abstract void execute();
	
	
	
}

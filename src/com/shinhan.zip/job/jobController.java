package com.shinhan.job;

import com.shinhan.common.CommonControllerInterface;

public class jobController implements CommonControllerInterface {

	@Override
	public void execute() {
		System.out.println("job Controller 입니다.");
		
	}

}
